#!/usr/bin/python

DOCUMENTATION = '''
---
module: match_gslb_vsuuid
GET target virtual service (vs) UUID. GET all GSLB Service's VS UUIDs. If the target vs's uuid is present, it returns the GSLB service name, pool, and ratio
'''

EXAMPLES = '''
  - name: Match VS UUID against all GSLB Services
    match_gslb_vsuuid:
      target_vs: vs1

author:
    - Your Name (@brandonandersen)
'''



import urllib3
urllib3.disable_warnings()
from avi.sdk.avi_api import ApiSession
from ansible.module_utils.basic import *

gslbservicename_list = []

def gslbservicematch(vs_name, avi_credentials):

    api = ApiSession.get_session(avi_credentials['controller'], avi_credentials['username'], avi_credentials['password'], tenant = avi_credentials['tenant'], api_version = avi_credentials['api_version'])

    vs_uuid = vs_name

    resp = api.get("gslbservice")
    for gslbservice in resp.json()['results']:
        gslbservicename = gslbservice['name']
        for pool in gslbservice['groups']:
                gslbpool = pool['name']
                for members in pool['members']:
                    if vs_uuid == members['vs_uuid']:
                        gslbitems = {'name': gslbservicename, 'poolname': gslbpool, 'ratio' : members['ratio'], 'cluster_uuid' : members['cluster_uuid'], 'vs_uuid' : members['vs_uuid']}
                        gslbservicename_list.append(gslbitems)
    return(gslbservicename_list)


def main():
    try:

        fields = {
            'target_vs': {'required': True, 'type': 'str'},
            'avi_credentials' : {'required': True, 'type': 'dict'}
        }
        
        module = AnsibleModule(argument_spec=fields)

        gslbservice = gslbservicematch(module.params['target_vs'],module.params['avi_credentials'])

        module.exit_json(gslbservicename = gslbservice)

    except UnboundLocalError:
        module.exit_json(msg="No Matching VS UUID for any GSLB service was found")
        
        
if __name__ == '__main__':
    main()
