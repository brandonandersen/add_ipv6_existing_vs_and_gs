1. Add controller authenication in vars/vars.yml
2. Add list of VS's in scope to vars/vars.yml.
3. Run main.yml to execute playbook